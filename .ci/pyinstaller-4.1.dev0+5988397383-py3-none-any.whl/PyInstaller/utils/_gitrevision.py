#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "5988397383"     # abbreviated commit hash
commit = "59883973838a09c9a55eceb2c4ba466d90786bd4"  # commit hash
date = "2020-11-02 17:34:08 +1100"   # commit date
author = "pyup.io bot <github-bot@pyup.io>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """tests: requirements: scheduled weekly dependency update (#5302)

* Update pygments from 2.7.1 to 2.7.2

* Update ipython from 7.18.1 to 7.19.0

* Update pandas from 1.1.3 to 1.1.4

* Update numpy from 1.19.2 to 1.19.3

* Update pillow from 8.0.0 to 8.0.1"""
