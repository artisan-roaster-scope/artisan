#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "7a926c78bf"     # abbreviated commit hash
commit = "7a926c78bf7b292bb99227f170457f59d059eda3"  # commit hash
date = "2020-10-29 20:33:31 +1100"   # commit date
author = "Mickaël Schoentgen <contact@tiger-222.fr>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """tests: replace skipif_xxx for platform-specific tests by markers [skip ci] (#5291)

"""
